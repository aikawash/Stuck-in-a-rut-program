TITLE:  Are you stuck in a RUT?
AUTHOR/PROGRAMMER: Aika Washington
DATE DUE: 10/04/17
DATE SUBMITTED: 10/04/17
COURSE TITLE: AP Computer Science
MEETING TIME(S): 10:00am MWF
DESCRIPTION: This is a Java program that asks the user their name and certain values that will allow the program to calculate their Rut score, which will allow them to determine if they are stuck in a rut. It includes another class, Calculator, as well as a tester file called CalculatorTester.
HONOR CODE: On my honor, I have neither given nor received any unauthorized aid on this assingment. Aika Washington
HOWTO: Open the program with the IDE of your choice that supports Java. Compile then run the program.
INPUT FILE: N/A
OUTPUT FILE: N/A
BIBLIOGRAPHY: Geek Logik: 50 Foolproof Equations for Everyday Life by Garth Sundem
RESOURCES: N/A
TUTORS: Shirley Mathur and Duncan Harmon explained concepts to me.
COMMENTS: A rut value cannot be bigger than the biggest integer in Java 
REFLECTION: It took me about 6 hours spread out over about four days to complete this assignment. I think my biggest obstacles in this assignment were understanding how to call methods from other classes. It clicked for me while creating the tester class, so I'm glas I understand it now. Another problem I had was that sometimes Nan would appear for the Rut score. This happened because I made a run time error, writing "part2" where I should have written "part3", leading to an error in the calculation that was extremely hard to track down. That was solved though!  